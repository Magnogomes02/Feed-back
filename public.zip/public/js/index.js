// js/index.js

// Grab your DOM elements
const filtroSdr     = document.getElementById('filtroSdr');
const filtroInicio  = document.getElementById('filtroDataInicio');
const filtroFim     = document.getElementById('filtroDataFim');
const filtroPeriodo = document.getElementById('filtroPeriodo');
const searchField   = document.getElementById('searchField');
const btnPesquisar  = document.getElementById('btnPesquisar');
const tabelaBody    = document.querySelector('#tabela tbody');
const nenhum        = document.getElementById('nenhum');

// Load unique SDRs into the filter dropdown
async function carregaSdRs() {
  const snapshot = await db.collection('avaliacoes').get();
  const setSdrs = new Set(snapshot.docs.map(d => d.data().sdr));
  setSdrs.forEach(email => {
    const opt = document.createElement('option');
    opt.value = email;
    opt.textContent = email;
    filtroSdr.append(opt);
  });
}

// Render the table rows, now including an “Ações” column
function renderLista(docs) {
  tabelaBody.innerHTML = '';
  if (docs.length === 0) {
    nenhum.style.display = 'block';
    return;
  }
  nenhum.style.display = 'none';

  docs.forEach(d => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${d.sdr}</td>
      <td>${new Date(d.datalig).toLocaleString()}</td>
      <td>${d.periodo}</td>
      <td>${d.protocolo}</td>
      <td>
        <button class="btn-ver" onclick="verRelatorio('${d.id}')">
          Ver
        </button>
      </td>
    `;
    tabelaBody.append(tr);
  });
}

// Redirect to the report page, passing the document ID in the query string
function verRelatorio(id) {
  window.location.href = `relatorio.html?id=${id}`;
}

// Perform the Firestore query + client-side filtering
async function pesquisar() {
  let query = db.collection('avaliacoes').orderBy('createdAt', 'desc');

  if (filtroSdr.value) {
    query = query.where('sdr', '==', filtroSdr.value);
  }
  if (filtroInicio.value) {
    const start = new Date(filtroInicio.value).toISOString();
    query = query.where('createdAt', '>=', start);
  }
  if (filtroFim.value) {
    const end = new Date(filtroFim.value);
    end.setDate(end.getDate() + 1);
    query = query.where('createdAt', '<', end.toISOString());
  }

  const snap = await query.get();
  // include the document ID for each record
  let docs = snap.docs.map(d => ({ id: d.id, ...d.data() }));

  // client-side text filtering
  if (filtroPeriodo.value.trim()) {
    const termo = filtroPeriodo.value.trim().toLowerCase();
    docs = docs.filter(d => d.periodo.toLowerCase().includes(termo));
  }
  if (searchField.value.trim()) {
    const termo = searchField.value.trim().toLowerCase();
    docs = docs.filter(d =>
      d.sdr.toLowerCase().includes(termo) ||
      d.periodo.toLowerCase().includes(termo) ||
      d.protocolo.toLowerCase().includes(termo)
    );
  }

  renderLista(docs);
}

// Wire up events
btnPesquisar.addEventListener('click', pesquisar);
if (searchField) {
  searchField.addEventListener('input', pesquisar);
}

// On page load, populate dropdown & run initial search
window.addEventListener('DOMContentLoaded', () => {
  carregaSdRs();
  pesquisar();
});