// js/formulario.js

// Lista dos 14 critérios padrão
const criterios = [
  "Identificação de perfil (PIT)",
  "Abertura e Rapport",
  "Apresentação de valor",
  "Convocação do analista fiscal",
  "Gestão de objeções",
  "Próximo passo definido",
  "Tom e linguagem",
  "Abordagem de Vendas",
  "Técnica no agendamento",
  "Efetividade",
  "Cordialidade e Relacionamento",
  "Prova social",
  "Qualificação de Leads",
  "Tempo de Resposta"
];

// Preenche a tabela de critérios dinamicamente
(function populaTabela() {
  const tbody = document.getElementById("criterios");
  criterios.forEach((nome, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${index + 1} - ${nome}</td>
      <td>
        <select name="aval_${index}" required>
          <option value="✔️ OK">✔️ OK</option>
          <option value="⚠️ Parcial">⚠️ Parcial</option>
          <option value="❌ Faltou">❌ Faltou</option>
          <option value="❎ Anulada">❎ Anulada</option>
        </select>
      </td>
      <td><textarea name="obs_${index}" rows="2"></textarea></td>
    `;
    tbody.appendChild(row);
  });
})();

// Trata o envio do formulário
document.getElementById("feedbackForm").addEventListener("submit", async function(e) {
  e.preventDefault();
  const data = new FormData(this);

  // Monta o objeto com as avaliações por critério
  const avaliacoes = {};
  criterios.forEach((nome, index) => {
    avaliacoes[nome] = {
      avaliacao: data.get(`aval_${index}`),
      observacao: data.get(`obs_${index}`) || ""
    };
  });

  // Dados gerais da avaliação
  const registro = {
    sdr:      data.get("sdr"),
    periodo:  data.get("periodo"),
    campanha: data.get("campanha"),
    protocolo:data.get("protocolo"),
    numero:   data.get("numero"),
    datalig:  data.get("datalig"),
    qualif:   data.get("qualif"),
    nota:     data.get("nota") || "",
    criterios: avaliacoes,
    createdAt: new Date().toISOString()
  };

  // Salva em localStorage para uso no relatório
  localStorage.setItem("relatorioSDR", JSON.stringify(registro));

  // Salva no Firestore e redireciona
  try {
    await db.collection("avaliacoes").add(registro);
    window.location.href = "relatorio.html";
  } catch (err) {
    alert("Erro ao salvar no Firebase: " + err.message);
  }
});
