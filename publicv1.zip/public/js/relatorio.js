window.addEventListener('DOMContentLoaded', async () => {
  // Config Firestore compat
  const db = firebase.firestore();
  const relatoriosRef = db.collection('avaliacoes');

  let snapshot;
  try {
    // Busca os 5 relatórios mais recentes (ordem crescente para o gráfico)
    snapshot = await relatoriosRef.orderBy('dataAvaliacao', 'desc').limit(5).get();
  } catch (e) {
    document.getElementById('dados').innerHTML = '<span style="color:#e74c3c">Erro ao consultar Firestore:<br>' + e.message + '</span>';
    return;
  }

  const docs = snapshot.docs.reverse();
  if (!docs.length) {
    document.getElementById('dados').innerHTML = 'Nenhum relatório encontrado.';
    return;
  }

  // Preenche arrays para o gráfico
  const labels = [];
  const notas = [];
  let relatorioAtual = docs[docs.length - 1].data();

  docs.forEach(doc => {
    const data = doc.data();
    let label = '';
    if (data.dataAvaliacao) {
      label = new Date(data.dataAvaliacao).toLocaleDateString('pt-BR');
    } else if (data.periodo) {
      label = data.periodo;
    }
    labels.push(label);
    notas.push(Number(data.notaFinal || 0));
  });

  // Espelhamento dos campos principais do formulário no relatório
  const dados = relatorioAtual;
  document.getElementById('dados').innerHTML = `
    <strong>SDR:</strong> ${dados.sdr || ''}<br>
    <strong>Período apurado:</strong> ${dados.periodo || ''}<br>
    <strong>Campanha:</strong> ${dados.campanha || ''}<br>
    <strong>Protocolo:</strong> ${dados.protocolo || ''}<br>
    <strong>Número:</strong> ${dados.numero || ''}<br>
    <strong>Data da ligação:</strong> ${dados.datalig || ''}<br>
    <strong>Qualificação:</strong> ${dados.qualif || ''}
  `;
  document.getElementById('resumo-calculo').innerHTML = `
    <div><strong>Nota calculada:</strong> ${(dados.notaFinal || 0).toFixed(1)} / 10</div>
  `;
  document.getElementById('titulo').innerText = dados.titulo || '';

  // Renderização dos critérios e recomendações finais
  const container = document.getElementById("conteudo");
  container.innerHTML = "";

  // Bloco de critérios (espelhando estrutura do formulário)
  const cores = {
    "✔️ OK": "cor-ok",
    "⚠️ Parcial": "cor-parcial",
    "❌ Faltou": "cor-faltou",
    "❎ Anulada": "cor-anulada"
  };
  let total = 0;
  const contagem = { "✔️ OK":0, "⚠️ Parcial":0, "❌ Faltou":0, "❎ Anulada":0 };

  if (dados.criterios && typeof dados.criterios === "object") {
    Object.entries(dados.criterios).forEach(([criterio, obj]) => {
      const bloco = document.createElement("div");
      bloco.className = `crit ${cores[obj.avaliacao] || ""}`;
      bloco.innerHTML = `
        <h3>${criterio} — ${obj.avaliacao}</h3>
        <p>${obj.observacao || 'Sem observações.'}</p>
      `;
      container.appendChild(bloco);

      if (obj.avaliacao !== "❎ Anulada") {
        contagem[obj.avaliacao]++;
        total++;
      } else {
        contagem["❎ Anulada"]++;
      }
    });
  }

  // Recomendações finais (campo "nota")
  if (dados.nota) {
    const recomendacoesDiv = document.createElement("div");
    recomendacoesDiv.className = "recomendacoes-finais";
    recomendacoesDiv.innerHTML = `<h3>Recomendações Finais</h3><p>${dados.nota}</p>`;
    container.appendChild(recomendacoesDiv);
  }

  // Gráfico de linha - curva de aprendizado
  const ctx = document.getElementById('grafico').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Nota Final',
        data: notas,
        fill: false,
        borderColor: '#3498db',
        backgroundColor: '#3498db',
        tension: 0.2,
        pointRadius: 6,
        pointBackgroundColor: '#fff',
        pointBorderColor: '#3498db'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: { title: { display: true, text: 'Avaliação' } },
        y: { title: { display: true, text: 'Nota' }, min: 0, max: 10 }
      }
    }
  });
});
