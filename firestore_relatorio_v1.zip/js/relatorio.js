
// relatorio.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app-compat.js";
import { getFirestore, collection, query, orderBy, limit, getDocs } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore-compat.js";

// Inicializa Firebase (já está feito no firebase-config.js)

window.addEventListener('DOMContentLoaded', async () => {
  const db = firebase.firestore(); // Usa compat API igual ao resto do seu projeto
  const relatoriosRef = db.collection('relatorios');

  // Consulta os 5 relatórios mais recentes (ordenados por dataAvaliacao)
  let snapshot = await relatoriosRef.orderBy('dataAvaliacao', 'desc').limit(5).get();
  const docs = snapshot.docs.reverse(); // Coloca em ordem crescente para o gráfico
  if (!docs.length) {
    document.getElementById('dados').innerText = 'Nenhum relatório encontrado.';
    return;
  }

  // Monta arrays para o gráfico
  const labels = [];
  const notas = [];
  let relatorioAtual = docs[docs.length - 1].data();

  docs.forEach(doc => {
    const data = doc.data();
    // Label = Data da avaliação (ou período)
    labels.push((data.dataAvaliacao || data.periodo || '').substring(0, 10));
    notas.push(Number(data.notaFinal || 0));
  });

  // Preenche campos principais
  const dados = relatorioAtual;
  document.getElementById('dados').innerHTML = `
    <strong>Período apurado:</strong> ${dados.periodo || ''}<br>
    <strong>Campanha:</strong> ${dados.campanha || ''}<br>
    <strong>Protocolo:</strong> ${dados.protocolo || ''}<br>
    <strong>Número:</strong> ${dados.numero || ''}<br>
    <strong>Data da ligação:</strong> ${dados.datalig || ''}<br>
    <strong>Qualificação:</strong> ${dados.qualif || ''}
  `;
  document.getElementById('resumo-calculo').innerHTML = `
    <div><strong>Nota calculada:</strong> ${(dados.notaFinal || 0).toFixed(1)} / 10</div>
    <!-- Você pode adicionar a distribuição aqui, se quiser -->
  `;
  document.getElementById('titulo').innerText = dados.titulo || '';

  // Gráfico de linha
  const ctx = document.getElementById('grafico').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Nota Final',
        data: notas,
        fill: false,
        borderColor: '#3498db',
        backgroundColor: '#3498db',
        tension: 0.2,
        pointRadius: 6,
        pointBackgroundColor: '#fff',
        pointBorderColor: '#3498db'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: { title: { display: true, text: 'Avaliação' } },
        y: { title: { display: true, text: 'Nota' }, min: 0, max: 10 }
      }
    }
  });
});
